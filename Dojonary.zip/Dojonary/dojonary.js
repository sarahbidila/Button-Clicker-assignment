function changeText(element){
    element.innerText = "Logout"
}

function deleteBtn (btn){
    btn.remove()
}

function alertPop (likeBtn){
    
    alert("Ninja was liked")
}
